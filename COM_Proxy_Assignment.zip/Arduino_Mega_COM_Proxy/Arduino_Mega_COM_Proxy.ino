/*
 * COM Proxy — Arduino Mega
 * Reads frames on Serial1 (Pin 18 RX / Pin 19 TX)
 * Forwards valid frames on Serial2 (Pin 16 RX / Pin 17 TX)
 * Frame format: START = 0x57 ... END = 0x15
 *
 * Pin Connections:
 *   Device A TX  →  Arduino Mega Pin 18 (Serial1 RX)
 *   Device A RX  ←  Arduino Mega Pin 19 (Serial1 TX)
 *   Device B RX  ←  Arduino Mega Pin 17 (Serial2 TX)
 *   Device B TX  →  Arduino Mega Pin 16 (Serial2 RX)
 *   GND          —  GND (common ground for all devices)
 *
 * Note: Arduino Mega is 5V logic.
 *       Do NOT connect directly to 3.3V devices without a level shifter.
 *       (Arduino Uno not recommended — only one hardware UART)
 */

#define BAUD_RATE   9600
#define START_BYTE  0x57
#define END_BYTE    0x15
#define MAX_FRAME   256

uint8_t  frameBuffer[MAX_FRAME];
uint16_t frameIndex = 0;
bool     inFrame    = false;

void setup() {
  Serial.begin(115200);       // USB debug monitor
  Serial1.begin(BAUD_RATE);   // Device A input  — RX=18, TX=19
  Serial2.begin(BAUD_RATE);   // Device B output — RX=16, TX=17
  Serial.println("COM Proxy ready. Waiting for 0x57...");
}

void loop() {
  while (Serial1.available()) {
    uint8_t b = (uint8_t)Serial1.read();

    // ── START detection ──────────────────────────────────────
    if (b == START_BYTE) {
      frameIndex = 0;
      inFrame    = true;
      frameBuffer[frameIndex++] = b;
      continue;
    }

    if (!inFrame) continue;            // ignore bytes outside a frame

    // ── Buffer overflow guard ─────────────────────────────────
    if (frameIndex >= MAX_FRAME) {
      Serial.println("[WARN] Frame overflow — discarded");
      inFrame    = false;
      frameIndex = 0;
      continue;
    }

    frameBuffer[frameIndex++] = b;

    // ── END detection ─────────────────────────────────────────
    if (b == END_BYTE) {
      // Forward the complete frame to Device B
      Serial2.write(frameBuffer, frameIndex);

      // Debug: print hex dump to monitor
      Serial.print("[FWD] ");
      for (uint16_t i = 0; i < frameIndex; i++) {
        char buf[4];
        sprintf(buf, "%02X ", frameBuffer[i]);
        Serial.print(buf);
      }
      Serial.println();

      inFrame    = false;
      frameIndex = 0;
    }
  }
}
