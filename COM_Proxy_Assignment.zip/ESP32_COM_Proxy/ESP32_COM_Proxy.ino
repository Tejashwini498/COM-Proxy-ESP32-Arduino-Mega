/*
 * COM Proxy — ESP32
 * Reads frames on UART2 (GPIO16 RX / GPIO17 TX)
 * Forwards valid frames on UART1 (GPIO4 RX / GPIO2 TX)
 * Frame format: START = 0x57 ... END = 0x15
 *
 * Pin Connections:
 *   Device A TX  →  ESP32 GPIO16 (Serial2 RX)
 *   Device A RX  ←  ESP32 GPIO17 (Serial2 TX)
 *   Device B RX  ←  ESP32 GPIO2  (Serial1 TX)
 *   Device B TX  →  ESP32 GPIO4  (Serial1 RX)
 *   GND          —  GND (common ground for all devices)
 *
 * Note: ESP32 is 3.3V logic. Use a level shifter if connecting to 5V devices.
 */

#define BAUD_RATE    9600
#define START_BYTE   0x57
#define END_BYTE     0x15
#define MAX_FRAME    256   // max bytes in one frame (adjust as needed)

// UART1: pins RX=4, TX=2
// UART2: pins RX=16, TX=17 (default ESP32 Serial2 pins)

uint8_t  frameBuffer[MAX_FRAME];
uint16_t frameIndex = 0;
bool     inFrame    = false;

void setup() {
  Serial.begin(115200);                        // USB debug monitor

  // Device A → ESP32 (input port)
  Serial2.begin(BAUD_RATE, SERIAL_8N1, 16, 17);

  // ESP32 → Device B (output port)
  Serial1.begin(BAUD_RATE, SERIAL_8N1, 4, 2);

  Serial.println("COM Proxy ready. Waiting for 0x57...");
}

void loop() {
  while (Serial2.available()) {
    uint8_t b = (uint8_t)Serial2.read();

    // ── START detection ──────────────────────────────────────
    if (b == START_BYTE) {
      frameIndex = 0;
      inFrame    = true;
      frameBuffer[frameIndex++] = b;
      continue;
    }

    if (!inFrame) continue;            // ignore bytes outside a frame

    // ── Buffer overflow guard ─────────────────────────────────
    if (frameIndex >= MAX_FRAME) {
      Serial.println("[WARN] Frame overflow — discarding");
      inFrame    = false;
      frameIndex = 0;
      continue;
    }

    frameBuffer[frameIndex++] = b;

    // ── END detection ─────────────────────────────────────────
    if (b == END_BYTE) {
      // Forward the complete frame to Device B
      Serial1.write(frameBuffer, frameIndex);

      // Debug: print hex dump to monitor
      Serial.print("[FWD] ");
      for (uint16_t i = 0; i < frameIndex; i++) {
        Serial.printf("%02X ", frameBuffer[i]);
      }
      Serial.println();

      inFrame    = false;
      frameIndex = 0;
    }
  }
}
